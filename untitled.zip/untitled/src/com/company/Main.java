package com.company;

public class Main {

    public static void main(String[] args) {
        AkilliCihaz A1 = new AkilliCihaz();
        A1.IslemSecimi();
    }
}
