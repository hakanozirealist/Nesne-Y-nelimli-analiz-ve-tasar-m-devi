package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class AgArayüzü implements IAgArayüzü {
    public int veriAl()
    {
        Scanner input = new Scanner(System.in);
        return input.nextInt();
    }

    private Connection baglan(){

        Connection conn=null;

        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Yetkili",
                    "postgres", "As2u0cfs");
            if (conn != null)
                System.out.println("Veritabanına bağlandı!");
            else
                System.out.println("Bağlantı girişimi başarısız!");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }

    public boolean ara(int kullaniciNo,int sifre){
        Kisiler kullanici=null;

        String sql= "SELECT *  FROM \"Kisiler\" WHERE \"KullaniciAd\"="+kullaniciNo;

        Connection conn=this.baglan();
        try{
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            //***** Bağlantı sonlandırma *****
            conn.close();
            int Sifre;
            int KullaniciAd;
            int KisiKod;

            while(rs.next())
            {
                KisiKod = rs.getInt("KisiKod");
                KullaniciAd = rs.getInt("KullaniciAd");
                Sifre = rs.getInt("Sifre");

                kullanici=new Kisiler(KisiKod, KullaniciAd, Sifre);
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(sifre==kullanici.getSifre())
        {
            System.out.println("Giriş Başarılı.....Yetkilerk kontol edildi...");
            System.out.println("Hoşgeldiniz  "+kullanici.getKullaniciAd()+"  Kullanici adlı kişi");
            return true;
        }
        else{
          System.out.println("Kullanıcı adı veya şifreniz yanlıştır....");
          return false;
        }

        //return kullanici;
    }



}
