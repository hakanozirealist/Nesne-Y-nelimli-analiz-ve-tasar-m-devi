package com.company;

import java.util.Random;

public class SicaklikAlgilayici implements ISicaklikAlgilayici{

    public int Sicaklik;

    public SicaklikAlgilayici()
    {
        Random s1 = new Random();
        Sicaklik = s1.nextInt(40);
    }

    public int sicaklikOku(int i)
    {
        Sicaklik = Sicaklik - i;
        return Sicaklik;
    }

    public int sicaklikGönder()
    {
        return Sicaklik;
    }

}
