package com.company;

public class Kisiler {
    private int KisiKod;
    private int KullaniciAd;
    private int Sifre;


    public Kisiler(int KisiKod,int KullaniciAd,int Sifre)
    {
        this.KisiKod = KisiKod;
        this.KullaniciAd = KullaniciAd;
        this.Sifre = Sifre;
    }

    public int getKullaniciAd(){return KullaniciAd;}
    public int getSifre(){return Sifre;}
}
