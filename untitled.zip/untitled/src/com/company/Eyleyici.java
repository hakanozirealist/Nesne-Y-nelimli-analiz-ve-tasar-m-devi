package com.company;

public class Eyleyici implements IEyleyici{
    public void sogutucuAc()
    {
        System.out.println("Soğutucu Açıldı.");

    }
    public void sogutucuKapat()
    {
        System.out.println("Soğutucu Kapatıldı");
    }
}
