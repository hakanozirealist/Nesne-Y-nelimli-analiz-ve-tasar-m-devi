package com.company;

public interface ISicaklikAlgilayici {
    public int sicaklikOku(int a);
    public int sicaklikGönder();
}
