package com.company;

public interface IAgArayüzü {
public int veriAl();
public boolean ara(int b,int c);
}
