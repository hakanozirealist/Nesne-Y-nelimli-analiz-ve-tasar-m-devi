package com.company;

public class AkilliCihaz {

    private IAgArayüzü agarayüzü;
    private IEyleyici eyleyici;
    private ISicaklikAlgilayici sicaklikalgilayici;

    public AkilliCihaz() {
        agarayüzü = new AgArayüzü();
        eyleyici = new Eyleyici();
        sicaklikalgilayici = new SicaklikAlgilayici();
    }
    private static final int SICAKLIK_GORUNTULE = 1;
    private static final int SOGUTUCU_AC = 2;
    private static final int SOGUTUCU_KAPAT = 3;
    private static final int CIKIS = 4;


    public void IslemSecimi()
    {
        System.out.println("Kullanici adınızı giriniz..:");
        int a =agarayüzü.veriAl();
        System.out.println("Şifrenizi Giriniz..:");
        int b = agarayüzü.veriAl();
        if(agarayüzü.ara(a,b)) {
            int secim;
            do {
                secim = menuGoster();
                switch (secim) {
                    case SICAKLIK_GORUNTULE:
                        System.out.println("Şuanki sıcaklık değeri  " + sicaklikalgilayici.sicaklikGönder() + " derece");
                        break;
                    case SOGUTUCU_AC:
                        eyleyici.sogutucuAc();
                        sicaklikalgilayici.sicaklikOku(3);
                        break;
                    case SOGUTUCU_KAPAT:
                        eyleyici.sogutucuKapat();

                }
            } while (secim != 4);
        }
        else {
            int secim;
            System.out.println("Herhangi bir yetkiniz yoktur");
            do{
                System.out.println("Çıkış yapmak için 4 e basın");
                secim = agarayüzü.veriAl();
            }
            while(secim != 4);
        }
        }


    private int menuGoster()
    {
        System.out.println("-------------------");
        System.out.println("Ana Menü");
        System.out.println("1-> Sıcaklığı Görüntüle");
        System.out.println("2-> Soğutucuyu aç");
        System.out.println("3-> Soğutucuyu kapat");
        System.out.println("4-> Çıkış");
        System.out.println("Seçiminiz...:");
        System.out.println("-------------------");
        return agarayüzü.veriAl();
    }
}
