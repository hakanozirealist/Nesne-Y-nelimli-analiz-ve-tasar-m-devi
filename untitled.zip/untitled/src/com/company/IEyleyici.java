package com.company;

public interface IEyleyici {
    public void sogutucuAc();
    public void sogutucuKapat();
}
